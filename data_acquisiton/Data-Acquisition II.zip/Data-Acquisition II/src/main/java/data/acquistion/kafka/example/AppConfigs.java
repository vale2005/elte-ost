package data.acquistion.kafka.example;

class AppConfigs {
    final static String applicationID = "Multi-Threaded-Producer";
    final static String topicName = "topic1";
    final static String kafkaConfigFileLocation = "kafka.properties";
    final static String[] eventFiles = {"data/histdata.csv", "data/Raw_data.csv"};
}
